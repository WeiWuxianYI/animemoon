<meta charset='utf-8'>
<meta http-equiv='X-UA-Compatible' content='IE=edge'>
<meta name='viewport' content='width=device-width,initial-scale=1'>
<link rel="shortcut icon" href="<?=$site_link?>/favicon.ico" />
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Rubik:300,400,500,700">
<link rel="stylesheet" href="<?=$site_link?>/public/styles/app.min.css<?=$style_version?>">
<script src="<?=$site_link?>/public/plugins/jquery.min.js<?=$style_version?>"></script>
<script src="<?=$site_link?>/public/plugins/font-awesome.min.js<?=$style_version?>"></script>
<script src="<?=$site_link?>/public/plugins/app.min.js<?=$style_version?>"></script>