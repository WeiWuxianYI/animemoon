<?php require_once("./settings/config.php")?>

<body>
<style>
	body,html{width:100%;overflow-x:hidden;color:white;font-size:1.5vw;font-family:Abel;background-color:#070707}.bodywidth{width:90%;margin-left:5%}.header{font-weight:700;font-size:1.8vw}
</style>
<div class="bodywidth">
	<font class="header">We're sorry, but you have been BANNED from <?=$site_title?></font><br><br>
	Please contact: <?=$site_main_contact?> if this is a problem.
</div>
</body>
